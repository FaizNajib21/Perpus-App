<?php

include 'database.php';

$database = new Database();
$database->getConnection();


?>