<?php

class Petugas {

    private $conn;
    private $table_name = "Petugas";

    public $ID;
    public $Email;
    public $Password;
    public $Role;

    public function __construct($db) {
        $this->conn = $db;
    }


    function create () {
        //insert
        $query = "INSERT INTO " . $this->table_name . " (Email, Password, Role)" .
                                  " VALUES (:Email, :Password, :Role)";

        $result = $this->conn->prepare($query);

        $this->Email = htmlspecialchars(strip_tags($this->Email));
        $this->Password = htmlspecialchars(strip_tags($this->Password));
        $this->Role = htmlspecialchars(strip_tags($this->Role));

        $result->bindParam(":Email", $this->Email);
        $result->bindParam(":Password", $this->Password);
        $result->bindParam(":Role", $this->Role);

        if($result->execute()) {
            return true;
        } else {
            return false;
        }

    }

    function readALL() {

        $query = "SELECT * FROM " . $this->table_name;

        $result = $this->conn->prepare($query);
        $result->execute();

        return $result;
    }

    function ReadOne() {

        $query = "SELECT * FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);
        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->Email = $row['email'];
        $this->Password = $row['password'];
        $this->Role = $row['role'];
    }

    function update() {
        $query = "UPDATE " . $this->table_name . " SET
            Email = :Email,
            Password = :Password,
            Role = :Role
            WHERE
            ID = :ID";

        echo $query;
        $result = $this->conn->prepare($query);

        $this->Email = htmlspecialchars(strip_tags($this->Email));
        $this->Password = htmlspecialchars(strip_tags($this->Password));
        $this->Role = htmlspecialchars(strip_tags($this->Role));

        $result->bindParam(":Email", $this->Email);
        $result->bindParam(":Password", $this->Password);
        $result->bindParam(":Role", $this->Role);
        $result->bindParam(":ID", $this->ID);

        $result->execute();
    }

    function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);

        $result->execute();
    }

}

?>